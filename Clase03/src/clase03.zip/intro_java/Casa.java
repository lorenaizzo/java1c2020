package intro_java;

public class Casa {
	String domicilio;
	String telefono;
	
	public Casa(String domicilio) {
		super();
		this.domicilio = domicilio;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDomicilio() {
		return domicilio;
	}
	
	
	
	

}
