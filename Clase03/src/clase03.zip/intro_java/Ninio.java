package intro_java;

public class Ninio extends Persona {

	Juguete juguetes[] = new Juguete[10];

	public Juguete[] getJuguetes() {
		return juguetes;
	}

	public void setJuguetes(Juguete[] juguetes) {
		this.juguetes = juguetes;
	}
	
	
	
}
