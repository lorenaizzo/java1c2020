package intro_java;

public class Juguete {

	
	String tipo;
	String nombre;
	
	
	public Juguete(String tipo) {
		super();
		this.tipo = tipo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTipo() {
		return tipo;
	}
	
	
	
	
}
