package clase03;

import java.util.*;

public class Album {

	//Atributos
	
	ArrayList<Foto> album;
	Foto album2[] = new Foto[5];
	
	//Metodos
	public ArrayList<Foto> getAlbum() {
		return album;
	}

	public void setAlbum(ArrayList<Foto> album) {
		this.album = album;
	}
	
	
	
}
